package com.app.pojos;

public enum CookingStatus {
	
	REJECTED,ACCEPTED,PREPARING,READY,NOTYETSTARTED

}
