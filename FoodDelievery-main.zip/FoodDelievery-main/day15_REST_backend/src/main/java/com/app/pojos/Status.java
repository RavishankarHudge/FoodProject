package com.app.pojos;

public enum Status {

	INACTIVE, ACTIVE
	
}
