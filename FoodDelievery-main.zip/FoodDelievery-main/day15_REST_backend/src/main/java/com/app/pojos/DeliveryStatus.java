package com.app.pojos;

public enum DeliveryStatus {
	
	ACCEPTED,DELIVERED, NOTYETACCEPTED, PICKEDUP

}
