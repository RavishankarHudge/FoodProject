package com.app.pojos;

public enum hotelType {
	VEG,NON_VEG,VEG_NONVEG

}
