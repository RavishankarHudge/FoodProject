package com.app.pojos;

public enum Scale {
	SMALL,MEDIUM,HALF,FULL,LARGE

}
